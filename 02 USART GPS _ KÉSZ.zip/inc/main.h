/* main.h */
#include "stm32f4xx.h"
extern void USERT1_INIT(void);
void Read_USART(void);


//uint8_t string_ready;
